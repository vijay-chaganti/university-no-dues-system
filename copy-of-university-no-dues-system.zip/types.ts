
export enum ApprovalStatus {
  PENDING = 'Pending',
  APPROVED = 'Approved',
  REJECTED = 'Rejected',
}

export enum UserRole {
  APPROVER = 'Approver',
  VIEWER = 'Viewer',
}

export interface DepartmentUser {
  id: string;
  name: string;
  role: UserRole;
}

export interface Department {
  id: string;
  name:string;
  users: DepartmentUser[];
}

export interface DepartmentApproval {
  deptId: string;
  deptName: string;
  status: ApprovalStatus;
  remarks?: string;
  approvedBy?: string;
}

export interface Student {
  urn: string; // Reg. Number
  name: string; // Full Name
  mobile: string;
  email: string;
  programmeName: string;
  batchYear: string;
  programType: string;
  schoolName: string;
  semester: string;
  fatherName: string;
  motherName: string;
  parentMobile: string;
  homeAddress: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  reportingProof: string[];
}

export interface PaymentDetails {
    utr: string;
    proofFileName: string;
}

export enum ApplicationStage {
    LOGIN,
    APPLICATION_FORM,
    PAYMENT,
    TRACKING,
    COMPLETED
}
