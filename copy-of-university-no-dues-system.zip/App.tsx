
import React, { useState, useEffect, useCallback } from 'react';
import { ApplicationStage, ApprovalStatus, DepartmentApproval, PaymentDetails, Student, UserRole } from './types';
import { DEPARTMENTS } from './constants';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

const App: React.FC = () => {
    const [stage, setStage] = useState<ApplicationStage>(ApplicationStage.LOGIN);
    const [student, setStudent] = useState<Student | null>(null);
    const [paymentDetails, setPaymentDetails] = useState<PaymentDetails | null>(null);
    const [approvals, setApprovals] = useState<DepartmentApproval[]>([]);
    const [coordinatorApproval, setCoordinatorApproval] = useState<ApprovalStatus>(ApprovalStatus.PENDING);
    const [hodApproval, setHodApproval] = useState<ApprovalStatus>(ApprovalStatus.PENDING);

    const startApprovalSimulation = useCallback(() => {
        const initialApprovals = DEPARTMENTS.map(dept => ({
            deptId: dept.id,
            deptName: dept.name,
            status: ApprovalStatus.PENDING
        }));
        setApprovals(initialApprovals);

        let approvalIndex = 0;
        const interval = setInterval(() => {
            if (approvalIndex < DEPARTMENTS.length) {
                const deptToApprove = DEPARTMENTS[approvalIndex];
                const approver = deptToApprove.users.find(u => u.role === UserRole.APPROVER);

                setApprovals(prev => prev.map((app, index) => 
                    index === approvalIndex 
                    ? { 
                        ...app, 
                        status: ApprovalStatus.APPROVED,
                        approvedBy: approver ? approver.name : 'System',
                      } 
                    : app
                ));
                approvalIndex++;
            } else {
                clearInterval(interval);
            }
        }, 1500); // Approve one department every 1.5 seconds

        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        if (stage === ApplicationStage.TRACKING) {
            startApprovalSimulation();
        }
    }, [stage, startApprovalSimulation]);

    useEffect(() => {
        const allDeptsApproved = approvals.length > 0 && approvals.every(a => a.status === ApprovalStatus.APPROVED);
        if (allDeptsApproved) {
            setTimeout(() => setCoordinatorApproval(ApprovalStatus.APPROVED), 1000);
        }
    }, [approvals]);
    
    useEffect(() => {
        if (coordinatorApproval === ApprovalStatus.APPROVED) {
            setTimeout(() => setHodApproval(ApprovalStatus.APPROVED), 1000);
        }
    }, [coordinatorApproval]);

    useEffect(() => {
        if (hodApproval === ApprovalStatus.APPROVED) {
            setTimeout(() => setStage(ApplicationStage.COMPLETED), 1500);
        }
    }, [hodApproval]);

    const handleLogin = (urn: string) => {
        setStudent({
            urn,
            name: '',
            mobile: '',
            email: '',
            programmeName: '',
            batchYear: '',
            programType: 'UG',
            schoolName: '',
            semester: '',
            fatherName: '',
            motherName: '',
            parentMobile: '',
            homeAddress: '',
            city: '',
            state: '',
            zipCode: '',
            country: '',
            reportingProof: [],
        });
        setStage(ApplicationStage.APPLICATION_FORM);
    };

    const handleApplicationSubmit = (studentData: Student) => {
        setStudent(studentData);
        setStage(ApplicationStage.PAYMENT);
    };

    const handlePaymentSubmit = (paymentData: PaymentDetails) => {
        setPaymentDetails(paymentData);
        setStage(ApplicationStage.TRACKING);
    };

    const handleLogout = () => {
        setStage(ApplicationStage.LOGIN);
        setStudent(null);
        setPaymentDetails(null);
        setApprovals([]);
        setCoordinatorApproval(ApprovalStatus.PENDING);
        setHodApproval(ApprovalStatus.PENDING);
    };

    const renderContent = () => {
        switch (stage) {
            case ApplicationStage.LOGIN:
                return <Login onLogin={handleLogin} />;
            default:
                if (!student) return <Login onLogin={handleLogin} />;
                return (
                    <Dashboard
                        stage={stage}
                        student={student}
                        approvals={approvals}
                        coordinatorApproval={coordinatorApproval}
                        hodApproval={hodApproval}
                        onApplicationSubmit={handleApplicationSubmit}
                        onPaymentSubmit={handlePaymentSubmit}
                        onLogout={handleLogout}
                    />
                );
        }
    };

    return (
        <div className="min-h-screen font-sans">
            {renderContent()}
        </div>
    );
};

export default App;
