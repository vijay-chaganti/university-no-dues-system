
import { Department, UserRole } from './types';

export const DEPARTMENTS: Department[] = [
  { 
    id: 'accounts', 
    name: 'Accounts Office',
    users: [
      { id: 'acc01', name: 'Alice Ray', role: UserRole.APPROVER },
      { id: 'acc02', name: 'Bob Smith', role: UserRole.VIEWER },
    ]
  },
  { 
    id: 'student_section', 
    name: 'Student Section',
    users: [
      { id: 'stu01', name: 'Charlie Day', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'pms', 
    name: 'PMS',
    users: [
      { id: 'pms01', name: 'Diana Prince', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'central_library', 
    name: 'Central Library',
    users: [
      { id: 'lib01', name: 'Eve Adams', role: UserRole.APPROVER },
      { id: 'lib02', name: 'Frank West', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'law_library', 
    name: 'Law Library',
    users: [
      { id: 'law01', name: 'Grace Hall', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'pharmacy_library', 
    name: 'Pharmacy Library',
    users: [
      { id: 'pha01', name: 'Henry Jones', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'crc', 
    name: 'CRC (Final Year/Alumni)',
    users: [
      { id: 'crc01', name: 'Ivy Green', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'it', 
    name: 'IT Department',
    users: [
      { id: 'it01', name: 'Jack Black', role: UserRole.APPROVER },
    ]
  },
  { 
    id: 'ncc', 
    name: 'NCC',
    users: [
      { id: 'ncc01', name: 'Karen White', role: UserRole.APPROVER },
    ]
  },
];
