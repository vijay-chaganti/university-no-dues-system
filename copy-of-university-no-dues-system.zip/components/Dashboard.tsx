
import React from 'react';
import { ApplicationStage, ApprovalStatus, DepartmentApproval, PaymentDetails, Student } from '../types';
import Header from './Header';
import ApplicationForm from './ApplicationForm';
import PaymentSection from './PaymentSection';
import StatusTracker from './StatusTracker';
import CertificateView from './CertificateView';

interface DashboardProps {
    stage: ApplicationStage;
    student: Student;
    approvals: DepartmentApproval[];
    coordinatorApproval: ApprovalStatus;
    hodApproval: ApprovalStatus;
    onApplicationSubmit: (studentData: Student) => void;
    onPaymentSubmit: (paymentData: PaymentDetails) => void;
    onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({
    stage,
    student,
    approvals,
    coordinatorApproval,
    hodApproval,
    onApplicationSubmit,
    onPaymentSubmit,
    onLogout
}) => {
    
    const renderStageContent = () => {
        switch (stage) {
            case ApplicationStage.APPLICATION_FORM:
                return <ApplicationForm student={student} onSubmit={onApplicationSubmit} />;
            case ApplicationStage.PAYMENT:
                return <PaymentSection onSubmit={onPaymentSubmit} />;
            case ApplicationStage.TRACKING:
                return (
                    <StatusTracker
                        approvals={approvals}
                        coordinatorApproval={coordinatorApproval}
                        hodApproval={hodApproval}
                    />
                );
            case ApplicationStage.COMPLETED:
                return <CertificateView student={student} />;
            default:
                return <div>Loading...</div>;
        }
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Header studentName={student.name || student.urn} onLogout={onLogout} />
            <main className="container mx-auto p-4 sm:p-6 lg:p-8">
                {renderStageContent()}
            </main>
        </div>
    );
};

export default Dashboard;
