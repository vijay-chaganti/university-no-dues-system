
import React from 'react';
import { Student } from '../types';

interface CertificateViewProps {
    student: Student;
}

const CertificateView: React.FC<CertificateViewProps> = ({ student }) => {
    const handlePrint = () => {
        window.print();
    };
    
    const currentDate = new Date().toLocaleDateString('en-GB', {
        day: '2-digit', month: 'long', year: 'numeric'
    });

    return (
        <div className="max-w-4xl mx-auto">
            <div className="bg-white p-8 md:p-12 rounded-xl shadow-lg" id="certificate">
                <div className="text-center border-b-2 border-gray-200 pb-6 mb-8">
                    <h1 className="text-4xl font-bold text-gray-800">CT University</h1>
                    <p className="text-lg text-gray-600 mt-2">Official Seal of The University</p>
                </div>
                <div className="text-center mb-8">
                    <h2 className="text-3xl font-semibold text-indigo-600 tracking-wider">NO DUES CERTIFICATE</h2>
                </div>
                <div className="text-lg text-gray-700 leading-relaxed space-y-4">
                    <p>This is to certify that <strong className="font-semibold text-gray-900">{student.name}</strong>, a student of <strong className="font-semibold text-gray-900">{student.programmeName} - Semester {student.semester}</strong>, with University Registration Number <strong className="font-semibold text-gray-900">{student.urn}</strong>, has cleared all outstanding dues with the university as of the date mentioned below.</p>
                    <p>This certificate is issued upon the verification and approval from all concerned departments.</p>
                </div>
                <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 text-center">
                    <div>
                        <p className="border-t-2 border-gray-300 pt-2">Registrar's Signature</p>
                    </div>
                    <div>
                        <p className="font-semibold">Date of Issue: {currentDate}</p>
                    </div>
                </div>
            </div>
            <div className="mt-8 text-center">
                <button
                    onClick={handlePrint}
                    className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                    <svg className="-ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M5 4v3H4a2 2 0 00-2 2v3a2 2 0 002 2h1v3a2 2 0 002 2h6a2 2 0 002-2v-3h1a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0H7v3h6V4zm0 8H7v4h6v-4z" clipRule="evenodd" />
                    </svg>
                    Print Certificate
                </button>
            </div>
        </div>
    );
};

export default CertificateView;
