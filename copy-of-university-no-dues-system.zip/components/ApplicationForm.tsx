
import React, { useState } from 'react';
import { Student } from '../types';

interface ApplicationFormProps {
    student: Student;
    onSubmit: (studentData: Student) => void;
}

const InputField: React.FC<{
    label: string;
    name: keyof Student;
    value: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    colSpan?: string;
    required?: boolean;
    readOnly?: boolean;
    type?: string;
}> = ({ label, name, value, onChange, colSpan = "col-span-1 md:col-span-2", required = true, readOnly = false, type="text" }) => (
    <div className={colSpan}>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700">{label}</label>
        <input
            type={type}
            id={name}
            name={name}
            value={value}
            onChange={onChange}
            required={required}
            readOnly={readOnly}
            className={`mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm ${readOnly ? 'bg-gray-100' : ''}`}
        />
    </div>
);

const ApplicationForm: React.FC<ApplicationFormProps> = ({ student, onSubmit }) => {
    const [formData, setFormData] = useState<Student>(student);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, checked } = e.target;
        setFormData(prev => {
            const proofs = prev.reportingProof.includes(name)
                ? prev.reportingProof.filter(p => p !== name)
                : [...prev.reportingProof, name];
            return { ...prev, reportingProof: proofs };
        });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    return (
        <div className="max-w-6xl mx-auto bg-white p-8 rounded-xl shadow-lg">
             <div className="flex justify-between items-center mb-6 border-b pb-6">
                <img src="https://www.ctuniversity.in/images/logo-dark.png" alt="CT University Logo" className="h-16" />
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-gray-800">Reporting Form for Continuing Students</h1>
                    <p className="text-gray-600 mt-1">(For Students - Term 2024)</p>
                </div>
                <div className="w-16"></div>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                    <h3 className="text-lg font-semibold text-gray-700 mb-4 bg-gray-100 p-2 rounded-md">Student Details</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <InputField label="Full Name" name="name" value={formData.name} onChange={handleChange} />
                        <InputField label="Reg. Number" name="urn" value={formData.urn} onChange={handleChange} readOnly={true} />
                        <InputField label="Mobile" name="mobile" value={formData.mobile} onChange={handleChange} type="tel" />
                        <InputField label="Email" name="email" value={formData.email} onChange={handleChange} type="email" />
                        <InputField label="Programme Name" name="programmeName" value={formData.programmeName} onChange={handleChange} />
                        <InputField label="Batch / Year" name="batchYear" value={formData.batchYear} onChange={handleChange} />
                        
                        <div className="col-span-1 md:col-span-4">
                            <label className="block text-sm font-medium text-gray-700">Program Type</label>
                            <div className="mt-2 flex flex-wrap gap-x-6 gap-y-2">
                                {['Diploma', 'UG', 'PG', 'Doctorate', 'Other'].map(type => (
                                    <label key={type} className="flex items-center text-sm">
                                        <input type="radio" name="programType" value={type} checked={formData.programType === type} onChange={handleChange} className="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500" />
                                        <span className="ml-2 text-gray-700">{type}</span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <InputField label="School Name" name="schoolName" value={formData.schoolName} onChange={handleChange} />
                        <InputField label="Semester" name="semester" value={formData.semester} onChange={handleChange} />
                        <InputField label="Father Name" name="fatherName" value={formData.fatherName} onChange={handleChange} />
                        <InputField label="Mother Name" name="motherName" value={formData.motherName} onChange={handleChange} />
                        <InputField label="Parent Mobile" name="parentMobile" value={formData.parentMobile} onChange={handleChange} type="tel" />
                        
                        <div className="col-span-1 md:col-span-3">
                            <label htmlFor="homeAddress" className="block text-sm font-medium text-gray-700">Home Address</label>
                            <input type="text" id="homeAddress" name="homeAddress" value={formData.homeAddress} onChange={handleChange} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm" />
                        </div>
                        
                        <InputField label="City" name="city" value={formData.city} onChange={handleChange} colSpan="col-span-1 md:col-span-1" />
                        <InputField label="State" name="state" value={formData.state} onChange={handleChange} colSpan="col-span-1 md:col-span-1" />
                        <InputField label="Zip Code" name="zipCode" value={formData.zipCode} onChange={handleChange} colSpan="col-span-1 md:col-span-1" />
                        <InputField label="Country" name="country" value={formData.country} onChange={handleChange} colSpan="col-span-1 md:col-span-1" />

                         <div className="col-span-1 md:col-span-4">
                            <label className="block text-sm font-medium text-gray-700">Student Reporting Proof</label>
                            <div className="mt-2 flex items-center space-x-6">
                                {['Offer Letter', 'Acceptance Letter'].map(proof => (
                                    <label key={proof} className="flex items-center text-sm">
                                        <input type="checkbox" name={proof} checked={formData.reportingProof.includes(proof)} onChange={handleCheckboxChange} className="h-4 w-4 text-indigo-600 border-gray-300 rounded-md focus:ring-indigo-500" />
                                        <span className="ml-2 text-gray-700">{proof}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="flex justify-end pt-4 border-t mt-8">
                    <button type="submit" className="inline-flex justify-center py-3 px-8 border border-transparent shadow-sm text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Save and Proceed to Payment
                    </button>
                </div>
            </form>
        </div>
    );
};

export default ApplicationForm;
