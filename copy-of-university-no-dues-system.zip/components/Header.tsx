
import React from 'react';

interface HeaderProps {
    studentName: string;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ studentName, onLogout }) => {
    return (
        <header className="bg-white shadow-md">
            <div className="container mx-auto flex justify-between items-center p-4">
                <div className="text-2xl font-bold text-indigo-600">
                    University No Dues System
                </div>
                <div className="flex items-center space-x-4">
                    <span className="text-gray-700 hidden sm:block">Welcome, {studentName}</span>
                    <button
                        onClick={onLogout}
                        className="px-4 py-2 text-sm font-medium text-white bg-red-500 rounded-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors duration-300"
                    >
                        Logout
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;
