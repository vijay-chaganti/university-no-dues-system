
import React from 'react';
import { DepartmentApproval, ApprovalStatus } from '../types';
import { ApprovedIcon, PendingIcon, RejectedIcon } from './icons/StatusIcons';

interface StatusTrackerProps {
    approvals: DepartmentApproval[];
    coordinatorApproval: ApprovalStatus;
    hodApproval: ApprovalStatus;
}

const StatusIcon: React.FC<{ status: ApprovalStatus }> = ({ status }) => {
    switch (status) {
        case ApprovalStatus.APPROVED:
            return <ApprovedIcon />;
        case ApprovalStatus.REJECTED:
            return <RejectedIcon />;
        case ApprovalStatus.PENDING:
        default:
            return <PendingIcon />;
    }
};

const getStatusClass = (status: ApprovalStatus) => {
    switch (status) {
        case ApprovalStatus.APPROVED:
            return 'text-green-600 bg-green-100';
        case ApprovalStatus.REJECTED:
            return 'text-red-600 bg-red-100';
        case ApprovalStatus.PENDING:
        default:
            return 'text-yellow-600 bg-yellow-100';
    }
};

const StatusTracker: React.FC<StatusTrackerProps> = ({ approvals, coordinatorApproval, hodApproval }) => {
    
    const allDeptsApproved = approvals.length > 0 && approvals.every(a => a.status === ApprovalStatus.APPROVED);

    return (
        <div className="max-w-4xl mx-auto bg-white p-8 rounded-xl shadow-lg">
            <h2 className="text-2xl font-bold text-gray-800 mb-6 border-b pb-4">Application Status Tracker</h2>
            <div className="space-y-8">
                {/* Department Approvals */}
                <div>
                    <h3 className="text-lg font-semibold text-gray-700 mb-4">Departmental Clearance</h3>
                    <ul className="space-y-4">
                        {approvals.map((approval) => (
                            <li key={approval.deptId} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                                <div className="flex items-start">
                                    <div className="flex-shrink-0">
                                        <StatusIcon status={approval.status} />
                                    </div>
                                    <div className="ml-4">
                                        <span className="font-medium text-gray-800">{approval.deptName}</span>
                                        {approval.status === ApprovalStatus.APPROVED && approval.approvedBy && (
                                            <p className="text-xs text-gray-500 mt-1">
                                                Approved by: <span className="font-medium">{approval.approvedBy}</span>
                                            </p>
                                        )}
                                    </div>
                                </div>
                                <span className={`px-3 py-1 text-xs font-semibold rounded-full self-center ${getStatusClass(approval.status)}`}>
                                    {approval.status}
                                </span>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Final Approvals */}
                <div>
                    <h3 className="text-lg font-semibold text-gray-700 mb-4">Final Approvals</h3>
                     <div className="p-4 border-l-4 border-gray-200">
                         {/* Coordinator Approval */}
                        <div className={`relative flex items-center pb-8 ${!allDeptsApproved ? 'opacity-50' : ''}`}>
                            <div className="absolute left-4 top-4 -ml-px mt-0.5 h-full w-0.5 bg-gray-300"></div>
                            <div className="flex items-center">
                                <StatusIcon status={coordinatorApproval} />
                                <span className="ml-4 font-medium text-gray-800">Class Coordinator / Mentor</span>
                            </div>
                            <span className={`ml-auto px-3 py-1 text-xs font-semibold rounded-full ${getStatusClass(coordinatorApproval)}`}>
                                {coordinatorApproval}
                            </span>
                        </div>

                         {/* HoD Approval */}
                        <div className={`relative flex items-center ${coordinatorApproval !== ApprovalStatus.APPROVED ? 'opacity-50' : ''}`}>
                            <div className="flex items-center">
                                <StatusIcon status={hodApproval} />
                                <span className="ml-4 font-medium text-gray-800">HoD / Principal</span>
                            </div>
                            <span className={`ml-auto px-3 py-1 text-xs font-semibold rounded-full ${getStatusClass(hodApproval)}`}>
                                {hodApproval}
                            </span>
                        </div>
                    </div>
                </div>
                 {hodApproval !== ApprovalStatus.APPROVED && (
                    <div className="text-center pt-4 text-gray-600 animate-pulse">
                        <p>Your application is being processed. Please check back later for updates.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default StatusTracker;
